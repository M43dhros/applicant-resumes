Prebuild validation not implemented Projects:
  MVC Projects:
    Integration service
        Conversions
        Libraries
    LogixAutomation
    LogixCodify - July 17th (completed)
    LogixConnect, connectportalservice - July 8th (completed)
    LogixExpress - Done 
    LogixFeedback - July 8th (completed)
    LogixWebsurveys - July 8th (completed)
    LogixIntegrator - July 2nd
    LogixNCV - July 17th (completed)
    Reconciler - Aug 14th
    LogixHRMS - TBD
    LogixReporting - YBD
    LogixRequestCCV - Applied
    LogixServices-APIM,Header&Footer ,IdentityManagement ,IDP, Notify - TBD 
    LogixStaffing - July 3rd ( completed )
    LogixStaffin-sos
    LogixTraining/ Learning July 8th ( completed )
Common build template not implemented Projects:
    MVC:
        LogixCodify
        LogixNCV
        LogixReconciler
        LogixService-sms
    Dotnet core:
        LogixConenct-Help
