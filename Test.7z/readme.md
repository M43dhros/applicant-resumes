# Get LogixHealth source code
This is a single repository (mono-repository aka monorepo), A monorepo is a version-controlled code repository that holds many projects. While these projects may be related, they are often logically independent and run by different teams.

    cd c:\
    git config --global http.sslVerify "false" 
    git clone https://azuredevops.logixhealth.com/LogixHealth/Software%20Engineering/_git/LogixApplications

# Repository structure
This repository has the following folders with respect to technology, front-end service, backend service, shared libraries, and etc. Example: 

    $LogixApplications
        |_ apps
            |_ _ angular        :- Stores code base of angular libraries and respective application code base as modules
            |_ _ consoleApps    :- Stores code base of console applications which are configured in windows task scheduler
            |_ _ desktop_apps   :- Stores code base of win-forms applications
            |_ _ mvc            :- Stores code base of asp.net mvc (model-view-controller) applications
            |_ _ php            :- Stores code base of php applications applications
            |_ _ ui             :- Stores code base of wireframes build using html/css
            |_ _ wpf            :- Stores code base of wpf (windows presentation foundation) applications
        |_ ci_cd                :- Contains build and release pipeline templates and respective application pipeline scripts
        |_ db_scripts           :- Contains database scripts / data-tier application package (dacpac)
        |_ platform
            |_ _ adfs           :- Contains code base for AD FS Extensions (which includes AD FS Web Theme, Sending OTP, TOU)
            |_ _ api            :- Contains code base for Application services (WCF/API)
            |_ _ apiGateway     :- Contains code base for API Gateway (External and Internal API Gateway)
            |_ _ cdn
            |_ _ libraries
            |_ _ sandboxAPI
            |_ _ workerService
        |_ reporting
            |_ _ ssis
        |_ test
            |_ _ automation
            |_ _ performance
            |_ _ poc
        |_ utilities
            |_ _ powershell_scripts
            |_ _ python

## Git Branching & Merge Strategy
Our branching strategy is scaled trunk based development: https://trunkbaseddevelopment.com/#scaled-trunk-based-development

We support rebase & fast-forward and squash commit merge strategies. As of May 25th, 2024 we do not support merge commits on the master branch.

Some practices that should be followed as it relates to branching:
* Short lived feature branches
* Frequent rebasing off master. Some helpful docs and images to understand rebasing:
    * https://www.atlassian.com/git/tutorials/merging-vs-rebasing
    * https://git-scm.com/docs/git-rebase
    * https://git-scm.com/book/en/v2/Git-Branching-Rebasing
    * https://www.atlassian.com/git/tutorials/rewriting-history/git-rebase
    * https://docs.github.com/en/get-started/using-git/about-git-rebase
* Do not merge master branch into feature branches

### Support: <a href="https://teams.microsoft.com/l/team/19%3aDdThkpLCJWObwBO4iAoJCGz5wIqpQH6Y1WGmr6o1NKk1%40thread.tacv2/conversations?groupId=7a9b7cc1-8e02-48da-bc5e-576fcb3e3a3d&tenantId=54ba6692-0195-4329-9a5d-08a427817083" target="_blank">Application support Teams channel</a>
